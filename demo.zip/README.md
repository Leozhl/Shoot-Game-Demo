# Shoot-Game-Demo
This is a shoot game demo, as the name suggests. You need to control a tiny character to face with endless enemies.

Operations  
W, A, S, D: Movement  
Left Click: Shoot  
Space: Change Bullet Kind(4 kinds in total: Black, Red, Green, Blue)

Bullets
* Black: No special efects.
* Red: More Damage.
* Green: Heal the character.
* Blue: Slow down the enemy.

When the enemy dies, it will create explotion according to the kinds of bullets it has taken.
* Red: BOOM! Explosion with pure damage.
* Green: Explosion with healing to the character.
* Blue: Explosion to freeze the enemies around.
